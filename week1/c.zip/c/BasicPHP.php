<?php
$names = array("Jack", "Jill", "John");
$Newnames = implode(",", $names);
echo $Newnames; 
?>


